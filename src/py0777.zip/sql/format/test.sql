SELECT  SUM(A.NPRC_AMT)  AS  NPRC_AMT /* ��ó���ݾ� �հ�*/ 
     ,  SUM(A.PRCS_AMT)  AS  PRCS_AMT /* ó���ݾ� �հ�*/
     ,  SUM(A.DRWG_FEE)  AS  DRWG_FEE /* ��ݼ����� �հ�*/
     ,  SUM(A.NPRC_CNT)  AS  NPRC_CNT /* ��ó���Ǽ�*/
     ,  SUM(A.PRCS_CNT)  AS  PRCS_CNT /* ó���Ǽ�*/
  FROM (
        SELECT  NVL( SUM(CASE WHEN IA.RSVN_TRNF_PRCS_SCD IN ('2','3') THEN IA.TRNF_AMT
                              ELSE 0
                          END ),0)  AS  NPRC_AMT/* ��ó���ݾ� �հ�*/    
              , NVL( SUM(CASE WHEN IA.RSVN_TRNF_PRCS_SCD = '1' AND IA.CNCL_YN ='N' THEN  IA.TRNF_AMT
                              ELSE 0 
                          END ),0)  AS  PRCS_AMT/* ó���ݾ� �հ�*/
              , NVL( SUM(CASE WHEN IA.RSVN_TRNF_PRCS_SCD = '1' AND IA.CNCL_YN ='N' THEN  IA.TR_FEE
                         ELSE 0 
                          END ),0)  AS  DRWG_FEE/* ��ݼ����� �հ�*/
              , NVL( SUM(CASE WHEN IA.RSVN_TRNF_PRCS_SCD IN ('2','3') THEN 1
                         ELSE 0 
                          END ),0)  AS  NPRC_CNT/* ��ó���Ǽ�*/
              , NVL( SUM(CASE WHEN IA.TR_SN > 0 AND IA.CNCL_YN ='N' THEN 1
                         ELSE 0 
                          END ),0)  AS  PRCS_CNT/* ó���Ǽ�*/                          
          FROM  RPF5470  IA   /* �ⳳ����_������ü���ó������*/
         WHERE  IA.RSVN_TRNF_HPE_DT  = :INQ_DT
           AND  IA.MNGM_TABR_COD = DECODE(:MNGM_TABR_COD,'%', IA.MNGM_TABR_COD, :MNGM_TABR_COD)
           AND  IA.RSVN_TRNF_HPE_HR_SCD = DECODE(:RSVN_TRNF_HPE_HR_SCD,'%', IA.RSVN_TRNF_HPE_HR_SCD, :RSVN_TRNF_HPE_HR_SCD)
           AND  IA.RSVN_TRNF_PRCS_SCD = DECODE(:RSVN_TRNF_PRCS_SCD,'%', IA.RSVN_TRNF_PRCS_SCD, :RSVN_TRNF_PRCS_SCD)
           AND  :INQ_SCD = '1'
         UNION
           ALL
        SELECT NVL( SUM(CASE WHEN IB.RSVN_TRNF_PRCS_SCD IN ('2','3') THEN IB.TRNF_AMT
                             ELSE 0
                        END ),0)  AS  NPRC_AMT/* ��ó���ݾ� �հ�*/    
              , NVL( SUM(CASE WHEN IB.RSVN_TRNF_PRCS_SCD = '1' AND IB.CNCL_YN ='N' THEN  IB.TRNF_AMT
                              ELSE 0 
                          END ),0)  AS  PRCS_AMT/* ó���ݾ� �հ�*/
              , NVL( SUM(CASE WHEN IB.RSVN_TRNF_PRCS_SCD = '1' AND IB.CNCL_YN ='N' THEN  IB.TR_FEE
                         ELSE 0 
                          END ),0)  AS  DRWG_FEE/* ��ݼ����� �հ�*/
              , NVL( SUM(CASE WHEN IB.RSVN_TRNF_PRCS_SCD IN ('2','3') THEN 1
                         ELSE 0 
                          END ),0)  AS  NPRC_CNT/* ��ó���Ǽ�*/
              , NVL( SUM(CASE WHEN IB.TR_SN > 0 AND IB.CNCL_YN ='N' THEN 1
                         ELSE 0 
                          END ),0)  AS  PRCS_CNT/* ó���Ǽ�*/
          FROM  RPF5470  IB   /* �ⳳ����_������ü���ó������*/
         WHERE  IB.RQS_DT  = :INQ_DT
           AND  IB.MNGM_TABR_COD = DECODE(:MNGM_TABR_COD,'%', IB.MNGM_TABR_COD, :MNGM_TABR_COD)
           AND  IB.RSVN_TRNF_HPE_HR_SCD = DECODE(:RSVN_TRNF_HPE_HR_SCD,'%', IB.RSVN_TRNF_HPE_HR_SCD, :RSVN_TRNF_HPE_HR_SCD)
           AND  IB.RSVN_TRNF_PRCS_SCD = DECODE(:RSVN_TRNF_PRCS_SCD,'%', IB.RSVN_TRNF_PRCS_SCD, :RSVN_TRNF_PRCS_SCD)
           AND  :INQ_SCD = '2'  
     )